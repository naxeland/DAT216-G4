import 'package:flutter/foundation.dart';

dbugPrint(message) {
  if (kDebugMode) {
    debugPrint(message);
  }
}
